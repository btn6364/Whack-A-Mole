package client.gui;

public interface Observer< Subject > {
    void update(Subject subject);
}
