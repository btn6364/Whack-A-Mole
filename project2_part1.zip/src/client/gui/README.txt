This file is only here so that Git will put its directory in the repository. You may delete it.
