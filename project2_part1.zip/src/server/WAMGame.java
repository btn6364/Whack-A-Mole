package server;

public class WAMGame implements Runnable{
    private WAMPlayer playerOne;

    private WAM game;

    public WAMGame(WAMPlayer playerOne){
        this.playerOne = playerOne;
    }

    @Override
    public void run(){

    }
}
